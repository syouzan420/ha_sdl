module Main (main) where

import MyApp(appMain)

main :: IO ()
main = appMain 
